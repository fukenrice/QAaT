package calc;

public class CalcException extends Exception {
    public CalcException(String s) {
        super(s);
    }
}
